const socket = io({ transports: ['websocket'] });

const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const messagesContainer = document.getElementById('messages-container');
const statusSpan = document.getElementById('status');
const messageInput = document.getElementById('message-input');
const usernameInput = document.getElementById('username');
const roomInput = document.getElementById('room');
const joinButton = document.getElementById('join-button');
const sendButton = document.getElementById('send-button');

let username = '';
let room = '';
let hasJoined = false;

function disableAutoCapitalization(input) {
  input.setAttribute('autocapitalize', 'none');
  input.setAttribute('autocorrect', 'off');
  input.setAttribute('spellcheck', 'false');
}

function setConnectionStatus(text, online) {
  statusSpan.textContent = text;
  statusSpan.className = online ? 'status online' : 'status offline';
}

function appendSystemMessage(text) {
  const div = document.createElement('div');
  div.className = 'system-message';
  div.textContent = text;
  messagesContainer.appendChild(div);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function appendChatMessage(data) {
  const div = document.createElement('div');
  const isMine = (data.sender || '') === username;
  div.className = `message${isMine ? ' message-mine' : ''}`;

  const header = document.createElement('div');
  header.className = 'message-header';

  const sender = document.createElement('strong');
  sender.textContent = data.sender || 'Anónimo';

  const timestamp = document.createElement('small');
  timestamp.textContent = data.timestamp || '';

  const body = document.createElement('p');
  // Evita interpretar el contenido del mensaje como HTML.
  body.textContent = data.text || '';

  header.append(sender, timestamp);
  div.append(header, body);
  messagesContainer.appendChild(div);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function joinChat() {
  const userInput = usernameInput.value.trim();
  const roomInputValue = roomInput.value.trim();

  if (!userInput || !roomInputValue) {
    alert('Por favor completa tu nombre y la sala.');
    return;
  }

  if (userInput.length > 30 || roomInputValue.length > 30) {
    alert('El nombre y la sala deben tener máximo 30 caracteres.');
    return;
  }

  username = userInput;
  room = roomInputValue;

  if (!socket.connected) {
    setConnectionStatus('Conectando...', false);
    return;
  }

  socket.emit('user:join', { username, room });
}

function handleTypingInput(event) {
  const input = event.target;
  if (event.key === 'Enter' || event.key === 'Tab' || event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) {
    return;
  }

  const start = input.selectionStart;
  const end = input.selectionEnd;
  const value = input.value;

  event.preventDefault();
  input.value = value.slice(0, start) + event.key + value.slice(end);
  const cursorPosition = start + event.key.length;
  input.setSelectionRange(cursorPosition, cursorPosition);
}

function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || !hasJoined || !socket.connected) return;

  if (text.length > 1000) {
    alert('El mensaje no puede superar los 1000 caracteres.');
    return;
  }

  socket.emit('chat:message', { text });
  messageInput.value = '';
  messageInput.focus();
}

joinButton.addEventListener('click', joinChat);
sendButton.addEventListener('click', sendMessage);
usernameInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') joinChat();
  else handleTypingInput(event);
});
roomInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') joinChat();
  else handleTypingInput(event);
});
messageInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') sendMessage();
  else handleTypingInput(event);
});

disableAutoCapitalization(usernameInput);
disableAutoCapitalization(roomInput);
disableAutoCapitalization(messageInput);

socket.on('connect', () => {
  setConnectionStatus('Conectado', true);
  if (username && room && hasJoined) {
    socket.emit('user:join', { username, room });
  }
});

socket.on('user:joined', (data) => {
  hasJoined = true;
  loginScreen.classList.remove('active');
  chatScreen.classList.add('active');
  document.getElementById('current-room').textContent = data.room;
  setConnectionStatus('Conectado', true);
  messageInput.focus();
});

socket.on('chat:message', appendChatMessage);
socket.on('system:info', (data) => appendSystemMessage(data.message));
socket.on('system:error', (data) => alert(data.message || 'Ocurrió un error.'));

socket.on('disconnect', () => {
  setConnectionStatus('Desconectado', false);
});

socket.on('connect_error', () => {
  setConnectionStatus('Error de conexión', false);
});
