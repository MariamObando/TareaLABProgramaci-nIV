﻿Chatcitoio

Aplicación web de chat en tiempo real con salas, desarrollada con Node.js, Express y Socket.IO.

¿Qué hace?

Permite entrar con un nombre de usuario, elegir una sala y chatear en tiempo real con otras personas que estén en la misma sala.

Requisitos

- Node.js 18 o superior
- npm
- Un navegador moderno

Ejecución

1. Abre la carpeta del proyecto en la terminal.
2. Instala dependencias:

   npm install

3. Inicia la aplicación:

   npm start o desde main.js

4. Abre en el navegador:

   http://localhost:3000

Uso

1. Escribe tu nombre y el nombre de la sala.
2. Pulsa Entrar.
3. Abre otra pestaña o ventana del navegador para probar otra sesión con el mismo nombre de sala.

Estructura principal

- server.js: servidor con Express y Socket.IO.
- public/index.html: interfaz de la app.
- public/app.js: lógica del cliente y eventos del chat.
- public/style.css: estilos visuales.

Tecnologías

- HTML
- CSS
- JavaScript
- Node.js
- Express
- Socket.IO

Limitaciones

- Es una versión local de demostración.
- Los mensajes no se guardan en base de datos.
- Se pierden al recargar o cerrar la sesión.

Documentación adicional

- docs/DOCUMENTACION_INTERNA.md
- docs/ENTREGABLES_PARA_INFORME.md
- capturas/README.txt
