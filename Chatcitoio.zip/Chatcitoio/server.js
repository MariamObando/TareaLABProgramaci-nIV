const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

function startServer() {
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, {
    // Forzamos el transporte WebSocket para mantener la conexión en tiempo real.
    transports: ['websocket']
  });

  app.use(express.static(path.join(__dirname, 'public')));

  io.on('connection', (socket) => {
    console.log(`Cliente conectado: ${socket.id}`);

    socket.on('user:join', (data) => {
      const username = typeof data?.username === 'string' ? data.username.trim() : '';
      const room = typeof data?.room === 'string' ? data.room.trim() : '';

      if (!username || !room || username.length > 30 || room.length > 30) {
        socket.emit('system:error', {
          message: 'El nombre y la sala son obligatorios y deben tener máximo 30 caracteres.'
        });
        return;
      }

      if (socket.room && socket.room !== room) {
        const previousRoom = socket.room;
        // Cuando el usuario cambia de sala, se evita que siga escuchando la anterior.
        socket.leave(previousRoom);
        if (socket.username) {
          socket.to(previousRoom).emit('system:info', {
            message: `${socket.username} ha salido del chat.`
          });
        }
      }

      const isNewRoomEntry = socket.room !== room;
      socket.join(room);
      socket.username = username;
      socket.room = room;

      socket.emit('user:joined', { room, username });

      if (isNewRoomEntry) {
        socket.to(room).emit('system:info', {
          message: `${username} se ha unido al chat.`
        });
      }
    });

    socket.on('chat:message', (data) => {
      const text = typeof data?.text === 'string' ? data.text.trim() : '';

      if (!socket.username || !socket.room || !text) return;
      if (text.length > 1000) {
        socket.emit('system:error', { message: 'El mensaje no puede superar los 1000 caracteres.' });
        return;
      }

      const payload = {
        sender: socket.username,
        text,
        timestamp: new Date().toLocaleTimeString('es-CR', {
          hour: '2-digit',
          minute: '2-digit'
        })
      };

      // Se distribuye el mensaje a todos los participantes de la sala actual.
      io.to(socket.room).emit('chat:message', payload);
    });

    socket.on('disconnect', () => {
      if (socket.username && socket.room) {
        socket.to(socket.room).emit('system:info', {
          message: `${socket.username} ha salido del chat.`
        });
      }
      console.log(`Cliente desconectado: ${socket.id}`);
    });
  });

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`Chatcitoio está disponible en http://localhost:${PORT}`);
  });
  return server;
}

module.exports = { startServer };
